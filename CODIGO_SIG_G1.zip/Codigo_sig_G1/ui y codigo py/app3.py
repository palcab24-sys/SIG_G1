import sys
import os
import pymysql
import itertools
from PyQt5 import QtWidgets, uic, QtGui # <--- AQUÍ AGREGUÉ QtGui
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QTableWidgetItem

# --- CONFIGURACIÓN DE RUTAS ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- CONFIGURACIÓN DE LA BASE DE DATOS ---
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root', 
    'password': '1234',  # <--- ¡INGRESA TU CONTRASEÑA AQUÍ!
    'db': 'lejuste_db',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

class MenuPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()
        ruta_ui = os.path.join(BASE_DIR, 'menu_principal.ui')
        uic.loadUi(ruta_ui, self)
        
        self.btn_gestioninv.clicked.connect(self.abrir_gestion_inventario)
        self.btn_armarp.clicked.connect(self.abrir_armar_pedidos)
        self.btn_shopify.clicked.connect(self.abrir_calculo_shopify)
        self.pushButton.clicked.connect(self.cerrar_sistema)

    def abrir_gestion_inventario(self):
        self.ventana_inv = GestionInventario()
        self.ventana_inv.show()
        self.close()

    def abrir_armar_pedidos(self):
        self.ventana_pedidos = ArmarPedidos()
        self.ventana_pedidos.show()
        self.close()
        
    def abrir_calculo_shopify(self):
        self.ventana_shop = CalculoShopify()
        self.ventana_shop.show()
        self.close()
        
    def cerrar_sistema(self):
        self.close()

class GestionInventario(QMainWindow):
    def __init__(self):
        super().__init__()
        ruta_ui = os.path.join(BASE_DIR, 'gestion_inventario.ui')
        uic.loadUi(ruta_ui, self)
        
        self.tbl_inv.setColumnCount(5)
        self.tbl_inv.setHorizontalHeaderLabels(["ID", "Aroma", "Tipo", "Stock Actual", "Nuevo Stock (Editar)"])
        header = self.tbl_inv.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        
        self.btn_volver.clicked.connect(self.volver_menu)
        self.btn_actualizar.clicked.connect(self.guardar_cambios)
        
        self.cargar_datos()

    def get_db_connection(self):
        return pymysql.connect(**DB_CONFIG)

    def cargar_datos(self):
        try:
            conn = self.get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    SELECT i.id_inventario, a.nombre_aroma, t.nombre_tipo, i.cantidad 
                    FROM tbl_inventario i
                    JOIN tbl_aromas a ON i.id_aroma = a.id_aroma
                    JOIN tbl_tipo_componente t ON i.id_tipo = t.id_tipo
                    ORDER BY a.nombre_aroma, t.nombre_tipo
                """
                cursor.execute(sql)
                result = cursor.fetchall()
                
                self.tbl_inv.setRowCount(0)
                for row_number, row_data in enumerate(result):
                    self.tbl_inv.insertRow(row_number)
                    self.tbl_inv.setItem(row_number, 0, QTableWidgetItem(str(row_data['id_inventario'])))
                    self.tbl_inv.setItem(row_number, 1, QTableWidgetItem(str(row_data['nombre_aroma'])))
                    self.tbl_inv.setItem(row_number, 2, QTableWidgetItem(str(row_data['nombre_tipo'])))
                    item_cant = QTableWidgetItem(str(row_data['cantidad']))
                    item_cant.setFlags(item_cant.flags() ^ 2)
                    self.tbl_inv.setItem(row_number, 3, item_cant)
                    self.tbl_inv.setItem(row_number, 4, QTableWidgetItem(""))
            conn.close()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo cargar inventario: {str(e)}")

    def guardar_cambios(self):
        conn = self.get_db_connection()
        try:
            updates_realizados = 0
            with conn.cursor() as cursor:
                for row in range(self.tbl_inv.rowCount()):
                    id_inv = self.tbl_inv.item(row, 0).text()
                    nuevo_stock_item = self.tbl_inv.item(row, 4)
                    
                    if nuevo_stock_item and nuevo_stock_item.text().strip():
                        nuevo_val = int(nuevo_stock_item.text())
                        sql = "UPDATE tbl_inventario SET cantidad = %s WHERE id_inventario = %s"
                        cursor.execute(sql, (nuevo_val, id_inv))
                        updates_realizados += 1
            
            conn.commit()
            QMessageBox.information(self, "Éxito", f"Se actualizaron {updates_realizados} registros.")
            self.cargar_datos()
        except ValueError:
            QMessageBox.warning(self, "Error", "Por favor ingrese solo números enteros.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error al guardar: {str(e)}")
        finally:
            conn.close()

    def volver_menu(self):
        self.menu = MenuPrincipal()
        self.menu.show()
        self.close()

class ArmarPedidos(QMainWindow):
    def __init__(self):
        super().__init__()
        ruta_ui = os.path.join(BASE_DIR, 'armar_pedidos.ui')
        uic.loadUi(ruta_ui, self)
        
        self.carrito = []
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setHorizontalHeaderLabels(["Producto", "Aromas Seleccionados"])
        header = self.tableWidget.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.Stretch)

        opciones = ["Unitario - Case", "Unitario - Recarga","Bipack", "Tripack", ]
        self.combo_tipo_pack.addItems(opciones)
        
        self.btn_agregar_carrito.clicked.connect(self.agregar_al_carrito)
        self.btn_procesar.clicked.connect(self.procesar_pedidos)
        self.pushButton.clicked.connect(self.volver_menu)

    def get_db_connection(self):
        return pymysql.connect(**DB_CONFIG)

    def volver_menu(self):
        self.menu = MenuPrincipal()
        self.menu.show()
        self.close()

    def agregar_al_carrito(self):
        tipo_pack = self.combo_tipo_pack.currentText()
        aromas_seleccionados = []
        
        cant_1 = self.spin_1.value()
        cant_2 = self.spin_2.value()
        cant_3 = self.spin_3.value()
        cant_4 = self.spin_4.value()
        
        for _ in range(cant_1): aromas_seleccionados.append(1)
        for _ in range(cant_2): aromas_seleccionados.append(2)
        for _ in range(cant_3): aromas_seleccionados.append(3)
        for _ in range(cant_4): aromas_seleccionados.append(4)
        
        cantidad_total = len(aromas_seleccionados)
        
        if tipo_pack == "Bipack" and cantidad_total != 2:
            QMessageBox.warning(self, "Regla", "Un Bipack debe tener exactamente 2 aromas.")
            return
        elif tipo_pack == "Tripack" and cantidad_total != 3:
            QMessageBox.warning(self, "Regla", "Un Tripack debe tener exactamente 3 aromas.")
            return
        elif "Unitario" in tipo_pack and cantidad_total != 1:
            QMessageBox.warning(self, "Regla", "La venta unitaria es de 1 solo producto.")
            return

        pedido = {"tipo": tipo_pack, "aromas": aromas_seleccionados}
        self.carrito.append(pedido)
        
        row = self.tableWidget.rowCount()
        self.tableWidget.insertRow(row)
        self.tableWidget.setItem(row, 0, QTableWidgetItem(tipo_pack))
        self.tableWidget.setItem(row, 1, QTableWidgetItem(str(aromas_seleccionados)))
        
        self.spin_1.setValue(0)
        self.spin_2.setValue(0)
        self.spin_3.setValue(0)
        self.spin_4.setValue(0)

    def procesar_pedidos(self):
        if not self.carrito:
            QMessageBox.warning(self, "Vacío", "El carrito está vacío.")
            return

        conn = self.get_db_connection()
        try:
            reporte_instrucciones = "<h3>Resultados del Procesamiento:</h3>"
            errores = False
            
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM tbl_inventario")
                inventario_db = cursor.fetchall()
                
                stock_local = {}
                inv_ids_map = {}
                for item in inventario_db:
                    key = (item['id_aroma'], item['id_tipo'])
                    stock_local[key] = item['cantidad']
                    inv_ids_map[key] = item['id_inventario']

                for i, pedido in enumerate(self.carrito):
                    tipo = pedido['tipo']
                    aromas = pedido['aromas']
                    lista_descuentos = []
                    
                    if "Unitario" in tipo:
                        aroma_id = aromas[0]
                        tipo_componente = 1 if "Case" in tipo else 2
                        nombre_comp = "Case" if tipo_componente == 1 else "Recarga"
                        
                        if stock_local.get((aroma_id, tipo_componente), 0) > 0:
                            stock_local[(aroma_id, tipo_componente)] -= 1
                            lista_descuentos.append(f"{nombre_comp} N°{aroma_id}")
                        else:
                            reporte_instrucciones += f"<p style='color:red'>Pedido {i+1}: Quiebre ({nombre_comp} N°{aroma_id})</p>"
                            errores = True
                            continue
                    else:
                        max_cases = -1
                        aroma_para_case = -1
                        for aroma_id in set(aromas):
                            cant_cases = stock_local.get((aroma_id, 1), 0)
                            if cant_cases > max_cases:
                                max_cases = cant_cases
                                aroma_para_case = aroma_id
                        
                        if max_cases <= 0:
                            reporte_instrucciones += f"<p style='color:red'>Pedido {i+1}: Sin Cases disponibles.</p>"
                            errores = True
                            continue

                        stock_local[(aroma_para_case, 1)] -= 1
                        lista_descuentos.append(f"Case N°{aroma_para_case}")
                        
                        aromas_para_recarga = list(aromas)
                        aromas_para_recarga.remove(aroma_para_case)
                        
                        falta_recarga = False
                        for aroma_id in aromas_para_recarga:
                            if stock_local.get((aroma_id, 2), 0) > 0:
                                stock_local[(aroma_id, 2)] -= 1
                                lista_descuentos.append(f"Recarga N°{aroma_id}")
                            else:
                                falta_recarga = True
                        
                        if falta_recarga:
                            reporte_instrucciones += f"<p style='color:red'>Pedido {i+1}: Falta stock Recargas.</p>"
                            errores = True
                        
                    if not errores:
                        reporte_instrucciones += f"<p><b>Pedido {i+1} ({tipo}):</b> {', '.join(lista_descuentos)}</p>"

                if not errores:
                    for key, cantidad_nueva in stock_local.items():
                        id_inv = inv_ids_map.get(key)
                        if id_inv:
                            cursor.execute("UPDATE tbl_inventario SET cantidad = %s WHERE id_inventario = %s", (cantidad_nueva, id_inv))
                    conn.commit()
                    reporte_instrucciones += "<br><b><i>Inventario actualizado.</i></b>"
                    self.carrito = []
                    self.tableWidget.setRowCount(0)
                else:
                    reporte_instrucciones += "<br><b><i>ERROR: No se guardó nada.</i></b>"

            self.instruccion.setHtml(reporte_instrucciones)

        except Exception as e:
            conn.rollback()
            QMessageBox.critical(self, "Error", str(e))
        finally:
            conn.close()

class CalculoShopify(QMainWindow):
    def __init__(self):
        super().__init__()
        ruta_ui = os.path.join(BASE_DIR, 'calculo_shopify.ui')
        uic.loadUi(ruta_ui, self)
        
        self.tbl_shopify.setColumnCount(3)
        self.tbl_shopify.setHorizontalHeaderLabels(["Tipo Pack", "Combinación Aromas", "Stock Máximo (Teórico)"])
        header = self.tbl_shopify.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        
        self.btn_volver.clicked.connect(self.volver_menu)
        self.btn_calcular.clicked.connect(self.calcular_disponibilidad)
        
        self.calcular_disponibilidad()

    def get_db_connection(self):
        return pymysql.connect(**DB_CONFIG)
        
    def volver_menu(self):
        self.menu = MenuPrincipal()
        self.menu.show()
        self.close()

    def calcular_disponibilidad(self):
        try:
            conn = self.get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM tbl_inventario")
                inventario_db = cursor.fetchall()
                stock_base = {}
                for item in inventario_db:
                    stock_base[(item['id_aroma'], item['id_tipo'])] = item['cantidad']
            conn.close()
            
            lista_resultados = []
            ids_aromas = [1, 2, 3, 4]
            
            for combo in itertools.combinations_with_replacement(ids_aromas, 2):
                stock_max = self.calcular_max_para_combo(list(combo), stock_base)
                lista_resultados.append(["Bipack", str(combo), stock_max])
                
            for combo in itertools.combinations_with_replacement(ids_aromas, 3):
                stock_max = self.calcular_max_para_combo(list(combo), stock_base)
                lista_resultados.append(["Tripack", str(combo), stock_max])
            
            self.tbl_shopify.setRowCount(0)
            for row_idx, data in enumerate(lista_resultados):
                self.tbl_shopify.insertRow(row_idx)
                self.tbl_shopify.setItem(row_idx, 0, QTableWidgetItem(data[0]))
                self.tbl_shopify.setItem(row_idx, 1, QTableWidgetItem(data[1]))
                
                item_stock = QTableWidgetItem(str(data[2]))
                
                # --- CORRECCIÓN DE ERROR AQUÍ (Usando QtGui) ---
                if data[2] == 0:
                    item_stock.setBackground(QtGui.QColor(255, 200, 200)) # Rojo suave
                else:
                    item_stock.setBackground(QtGui.QColor(200, 255, 200)) # Verde suave
                    
                self.tbl_shopify.setItem(row_idx, 2, item_stock)

        except Exception as e:
            QMessageBox.critical(self, "Error Cálculo", str(e))

    def calcular_max_para_combo(self, aromas, stock_real):
        stock_simulado = stock_real.copy()
        contador_packs = 0
        
        while True:
            max_cases = -1
            aroma_para_case = -1
            
            for aroma_id in set(aromas):
                cant = stock_simulado.get((aroma_id, 1), 0)
                if cant > max_cases:
                    max_cases = cant
                    aroma_para_case = aroma_id
            
            if max_cases <= 0:
                break
            
            stock_simulado[(aroma_para_case, 1)] -= 1
            
            aromas_recarga = list(aromas)
            aromas_recarga.remove(aroma_para_case)
            
            posible = True
            temp_stock_recargas = stock_simulado.copy()
            
            for aroma_id in aromas_recarga:
                if temp_stock_recargas.get((aroma_id, 2), 0) > 0:
                    temp_stock_recargas[(aroma_id, 2)] -= 1
                else:
                    posible = False
                    break
            
            if posible:
                stock_simulado = temp_stock_recargas
                contador_packs += 1
            else:
                break
                
        return contador_packs

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    window = MenuPrincipal()
    window.show()
    sys.exit(app.exec_())